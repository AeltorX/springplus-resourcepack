#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D InSampler;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};
layout(std140) uniform SpringPlusTransition {
    vec4 Transition;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

float hash(float x) {
    return fract(sin(x * 127.1 + 49.73) * 43758.5453);
}

float pathNoise(float y, float seed) {
    float cell = floor(y);
    float t = fract(y);
    return mix(hash(cell + seed), hash(cell + 1.0 + seed), t);
}

float spine(float y, float seed, float phase) {
    float baseline = 0.045 + 0.040 * sin(y * 5.0 + seed + phase * 3.6);
    float jitter = (pathNoise(y * 29.0 + 2.2 * phase, seed) - 0.5) * 0.083;
    float detail = (pathNoise(y * 61.0, seed + 3.7) - 0.5) * 0.018;
    return baseline + jitter + detail;
}

float band(float x, float y, float seed, float phase, float width, float rangeStart, float rangeEnd) {
    float taper = smoothstep(rangeStart, rangeStart + 0.065, y)
        * (1.0 - smoothstep(rangeEnd - 0.075, rangeEnd, y));
    float fromArc = abs(x - spine(y, seed, phase));
    return exp2(-fromArc / width) * taper;
}

float fork(float x, float y, float seed, float phase, float split, float slope, float aspect) {
    float t = (y - split) / slope;
    if (t < 0.0 || t > 1.0) return 0.0;
    float anchor = spine(split, seed, phase);
    float direction = slope < 0.0 ? -0.043 : 0.073;
    float jagged = (pathNoise(t * 8.0, seed + 11.0) - 0.5) * 0.033;
    float target = anchor + t * direction + jagged * sin(3.14 * t);
    float width = mix(0.0018, 0.0004, t) / aspect * 1.6;
    return exp2(-abs(x - target) / width) * (1.0 - t);
}

void main() {
    vec2 uv = texCoord;
    vec3 scene = texture(InSampler, uv).rgb;
    float darkness = Transition.x;
    float storm = Transition.y;
    float phase = Transition.z;
    vec3 rgb = scene * (1.0 - darkness);
    bool left = uv.x < 0.5;
    float x = left ? uv.x : 1.0 - uv.x;
    if (storm > 0.0 && x < 0.25) {
        float aspect = max(1.0, OutSize.x / max(OutSize.y, 1.0));
        float y = left ? uv.y : 1.0 - uv.y;
        float seed = left ? 19.0 : 67.0;
        float envelope = sin(phase * 2.9) * (1.0 - 0.46 * phase);
        float edge = pow(1.0 - smoothstep(0.0, 0.19, x), 2.2);
        float halo = band(x, y, seed, phase, 0.018, 0.065, 0.94);
        float core = band(x, y, seed, phase, 0.0028 * 1.6 / aspect, 0.065, 0.94);
        float arms = fork(x, y, seed, phase, 0.28, 0.20, aspect)
            + fork(x, y, seed, phase, 0.62, -0.19, aspect)
            + 0.75 * fork(x, y, seed, phase, 0.72, 0.21, aspect);
        rgb += storm * envelope * (edge * vec3(0.10, 0.047, 0.26)
            + halo * vec3(0.29, 0.10, 0.55)
            + core * vec3(0.41, 0.53, 0.86)
            + arms * vec3(0.44, 0.27, 0.73));
    }
    fragColor = vec4(clamp(rgb, 0.0, 1.0), 1.0);
}